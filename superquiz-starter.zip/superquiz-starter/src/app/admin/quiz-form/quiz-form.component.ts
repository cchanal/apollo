import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz-form',
  templateUrl: './quiz-form.component.html'
})
export class QuizFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
