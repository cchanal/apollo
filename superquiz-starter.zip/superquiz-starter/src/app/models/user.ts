/**
 * @file
 * A user logged into the application.
 */
export class User {
  constructor(options: any) {}
}
